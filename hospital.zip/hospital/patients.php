<?php
session_start();
require 'db_connect.php';
include 'inc/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $sex = $_POST['sex'];
    $status = $_POST['status'];
    $blood = $_POST['blood'];
    $number = $_POST['number'];
    $date = date('Y-m-d');

    $stmt = $conn->prepare("INSERT INTO patients (name, age, sex, status, blood, number, date) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssss", $name, $age, $sex, $status, $blood, $number, $date);
    if ($stmt->execute()) {
        $success = "Patient added successfully!";
    } else {
        $error = "Error adding patient.";
    }
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Patient Management</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="post" action="patients.php">
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" name="age" id="age" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="sex" class="form-label">Sex</label>
                <select name="sex" id="sex" class="form-control" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">Status</label>
                <input type="text" name="status" id="status" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="blood" class="form-label">Blood Group</label>
                <input type="text" name="blood" id="blood" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="number" class="form-label">Contact Number</label>
                <input type="text" name="number" id="number" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Patient</button>
        </form>
        
    </div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


