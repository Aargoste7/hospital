<?php
session_start();
require 'db_connect.php';
include 'inc/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch all doctors for report
$doctor_query = "SELECT * FROM doctors";
$result = $conn->query($doctor_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Doctor Report</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Sex</th>
                    <th>Certification</th>
                    <th>Tittle</th>
                    <th>Number</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($doctor = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $doctor['id']; ?></td>
                        <td><?php echo htmlspecialchars($doctor['name']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['age']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['sex']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['certificate']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['title']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['number']); ?></td>
                        <td><?php echo htmlspecialchars($doctor['date']); ?></td>
                        <td>
                            <a href="edit_doctor.php?id=<?php echo $doctor['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_doctor.php?id=<?php echo $doctor['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this doctor?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

