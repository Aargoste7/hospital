<?php
session_start();
require 'db_connect.php';
include 'inc/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch all billing records for report
$billing_query = "SELECT * FROM billing";
$result = $conn->query($billing_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Billing Report</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Payment Name</th>
                    <th>Amount</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($billing = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $billing['id']; ?></td>
                        <td><?php echo htmlspecialchars($billing['payment_name']); ?></td>
                        <td><?php echo htmlspecialchars($billing['amount']); ?></td>
                        <td><?php echo htmlspecialchars($billing['date']); ?></td>
                        <td>
                            <a href="edit_billing.php?id=<?php echo $billing['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_billing.php?id=<?php echo $billing['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this billing record?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
