<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            font-family: Arial, sans-serif;
            background-color: #f4f7fa;
        }
        .sidebar {
            min-width: 250px;
            background-color: #343a40;
            color: #ffffff;
            padding: 20px;
            height: 100vh;
        }
        .sidebar h2 {
            color: #ffffff;
        }
        .sidebar .nav-link {
            color: #ffffff;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
        .header {
            padding: 10px 0;
            border-bottom: 2px solid #dee2e6;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Hospital</h2>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard.php">Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="patients.php">Patients</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="doctors.php">Doctors</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="billing.php">Billing</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="users.php">Users</a>
            </li>
            <!-- meshaan waa wixii edit iyo delete ah  -->
   <!--          <li class="nav-item">
                <a class="nav-link" href="edit_patient.php">Edit_patient</a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="delete_patient.php">Delete_patient</a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="edit_doctor.php">Edit_doctor</a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="delete_doctor.php">Delete_doctor</a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="edit_billing.php">Edit_billing</a>
            </li> 
            <li class="nav-item">
                <a class="nav-link" href="delete_billing.php"></a>
            </li> 

 -->

            <!-- meshan wa pageska caadiga -->
            <li class="nav-item">
                <a class="nav-link" href="patient_report.php">Patient Report</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="doctor_report.php">Doctor Report</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="billing_report.php">Billing Report</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="user_report.php">User Report</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>

    <div class="content">
        
        

       

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
