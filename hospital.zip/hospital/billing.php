<?php
session_start();
require 'db_connect.php';
include 'inc/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payment_name = $_POST['payment_name'];
    $amount = $_POST['amount'];
    $date = date('Y-m-d');

    $stmt = $conn->prepare("INSERT INTO billing (payment_name, amount, date) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $payment_name, $amount, $date);
    if ($stmt->execute()) {
        $success = "Billing entry added successfully!";
    } else {
        $error = "Error adding billing entry.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Billing and Payments</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="post" action="billing.php">
            <div class="mb-3">
                <label for="payment_name" class="form-label">Payment Name</label>
                <input type="text" name="payment_name" id="payment_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="amount" class="form-label">Amount</label>
                <input type="number" name="amount" id="amount" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Billing Entry</button>
        </form>

        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
